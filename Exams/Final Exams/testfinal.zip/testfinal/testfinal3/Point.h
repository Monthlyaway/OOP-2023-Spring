#ifndef _Point_H
#define _Point_H

//TODO


#endif
