#ifndef _Line_H
#define _Line_H

//TODO

#endif
