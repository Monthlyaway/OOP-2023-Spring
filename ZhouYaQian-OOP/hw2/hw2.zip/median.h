#ifndef GUARD_median_h
#define GUARD_median_h

#include <vector>
double median(std::vector<double> vec);
double average(const std::vector<double> &vec);

#endif