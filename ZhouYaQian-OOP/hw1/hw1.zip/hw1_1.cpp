#include <algorithm>
#include <iostream>
#include <ios>
#include <string>
#include <iomanip>
#include <vector>
using namespace std;

int main() 
{ 
	//TODO
	return 0; 
} 
