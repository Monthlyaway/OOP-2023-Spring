#ifndef __VEC_H
#define __VEC_H
#include <memory>
//TODO


#endif
