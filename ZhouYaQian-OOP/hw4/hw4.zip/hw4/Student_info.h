#ifndef GUARD_Student_info
#define GUARD_Student_info

// TODO

class Student_info{
	// TODO

};

// TODO

#endif
