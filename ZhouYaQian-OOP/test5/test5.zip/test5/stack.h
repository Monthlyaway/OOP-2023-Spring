#ifndef __STACK_H
#define __STACK_H
#include <memory>

template <class T> 
class myStack{
	public:
		//TODO
		

	private:
		//TODO
};

//TODO

#endif
