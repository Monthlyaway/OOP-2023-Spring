//
//  main.cpp
//  test5
//

//


#include<iostream>
//#include<stack>
#include"stack.h"
using namespace std;

int main()
{
    myStack<int> s;
    int num;
    
    cout<<"------Test for Stack-------"<<endl;
    cout<<"Input number:"<<endl;
    
    while(cin>>num)
    {
        s.push(num);
    }
    
    cout<<"The Stack has "<<s.size()<<" numbers.\nThey are:"<<endl;
    while(!s.empty())
    {
        cout<<s.top()<<" ";
        s.pop();
    }
    cout<<"\nNow the size is "<<s.size()<<endl;
    return 0;
}
